<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">
    <h2 style="margin-bottom: 20px;">Contact Us</h2>

    <section class="features">
      <div class="feature-card">
        <h3>Head Office</h3>
        <p>Planet SR<br>Near Cumilla Zilla School Road<br>Cumilla - 3500</p>
        <p>Phone: 01918634727</p>
        <p>Email: sabab@gmail.com</p>
      </div>
      <div class="feature-card">
        <h3>Branch Office</h3>
        <p>BN Mall<br>Block D, Road 8, Banasree<br>Dhaka - 1212</p>
        <p>Phone: 01849900880</p>
        <p>Email: rafibhai@gmail.com</p>
      </div>
    </section>
  </div>


</div>

<?php include('Footer.php'); ?>