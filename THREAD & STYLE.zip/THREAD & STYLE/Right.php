<div id="right-col">
  <h2>Login</h2>
  <div class="scroll">
    <form name="form1" method="post" action="login.php">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="26">User Name:</td>
        </tr>
        <tr>
          <td height="30">
            <input
              type="text"
              name="txtUserName"
              size="18"
              id="txtUserName"
              required
              placeholder="Enter username" />
          </td>
        </tr>
        <tr>
          <td height="26">Password:</td>
        </tr>
        <tr>
          <td height="31">
            <input
              type="password"
              name="txtPassword"
              size="18"
              id="txtPassword"
              required
              placeholder="Enter password" />
          </td>
        </tr>
        <tr>
          <td height="29">User Type:</td>
        </tr>
        <tr>
          <td>
            <p>
              <label>
                <input type="radio" name="rdType" value="Admin" required> Admin
              </label><br>
              <label>
                <input type="radio" name="rdType" value="Customer"> Customer
              </label>
            </p>
          </td>
        </tr>
        <tr>
          <td>
            <center>
              <input
                type="submit"
                name="button"
                id="button"
                value="Login"
                style="margin-top: -10px;">
            </center>
          </td>
        </tr>
      </table>
    </form>
  </div>
  <h2>&nbsp;</h2>
  <ul class="side">
    <!-- You can dynamically add links or categories here if needed -->
  </ul>
</div>