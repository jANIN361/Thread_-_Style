<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content">
    <main class="container">
      <!-- Hero Section -->
      <section class="hero">
        <div class="hero-text">
          <h1>Where comfort meets confidence</h1>
          <p>Discover the perfect blend of style and comfort with Thread & Style. Our collection is designed to make you feel confident and at ease, every day.</p>
          <a href="Products.php" class="btn">Shop Now</a>
        </div>
        <div class="hero-img">
          <img src="asset/images/Main_fream.jpg" alt="Clothes">   
        </div>
      </section>

      <!-- Featured Categories
      <section class="features">
        <div class="feature-card">
          <img src="asset/images/Jeans.jpg" alt="Jeans">
          <h3>Jeans</h3>
        </div>
        <div class="feature-card">
          <img src="asset/images/asd.jpg" alt="Blazers">
          <h3>Blazers</h3>
        </div>
        <div class="feature-card">
          <img src="asset/images/images.jpg" alt="T-Shirts">
          <h3>T-Shirts</h3>
        </div>
      </section>  -->

    </main>
  </div>

  
  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>