<?php
include('Header.php');
$con = mysqli_connect("localhost", "root", "", "shopping");
$sql = "SELECT * FROM Offer_Master";
$result = mysqli_query($con, $sql);
?>

<div id="wrapper">
  <div id="content" class="container">
    <h2 style="margin-bottom: 20px;">Special Offers</h2>

    <section class="features">
      <?php while ($row = mysqli_fetch_array($result)) : ?>
        <div class="feature-card">
          <h3><?= ($row['Offer']) ?></h3>
          <p><?= ($row['Detail']) ?></p>
          <small>Valid Until: <?= ($row['Valid']) ?></small>
        </div>
      <?php endwhile; ?>
    </section>

    <h2 style="margin: 50px 0 20px;">Trending Categories </h2>
      <section class="features">
        <?php
        $con = mysqli_connect("localhost", "root", "", "shopping");
        $sql = "SELECT * FROM Category_Master";
        $result = mysqli_query($con, $sql);

        while ($row = mysqli_fetch_array($result)) {
          $Id = $row['CategoryId'];
          $CategoryName = $row['CategoryName'];
          $Description = $row['Description'];
          $Image = $row['Image'];
        ?>
          <div class="feature-card">
            <img src="Products/<?php echo $Image; ?>" alt="<?php echo $CategoryName; ?>">
            <h3><?php echo $CategoryName; ?></h3>
            <p><?php echo $Description; ?></p>
            <a href="Products.php?CategoryId=<?php echo $Id; ?>" class="btn">View Products</a>
          </div>
        <?php } ?>
      </section>
  </div>

  <?php include('Right.php'); ?>
</div>

<?php
mysqli_close($con);
include('Footer.php');
?>
