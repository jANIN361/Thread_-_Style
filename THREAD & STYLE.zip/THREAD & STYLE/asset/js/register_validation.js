
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registerForm');

  const fields = {
    txtName: {
      validate: value => value.trim() !== '',
      message: 'Name is required.'
    },
    txtEmail: {
      validate: value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
      message: 'Please enter a valid email address.'
    },
    txtMobile: {
      validate: value => /^\d{10}$/.test(value),
      message: 'Enter a 10‑digit mobile number except first zero.'
    },
    txtAddress: {
      validate: value => value.trim() !== '',
      message: 'Address is required.'
    }
  };

  function showError(fieldId, text) {
    const span = document.getElementById(fieldId + 'Error');
    span.textContent = text || '';
  }

  // Live validation: on 'input' event for each field
  Object.keys(fields).forEach(fieldId => {
    const input = document.getElementById(fieldId);
    input.addEventListener('input', () => {
      const { validate, message } = fields[fieldId];
      showError(fieldId, validate(input.value) ? '' : message);
    });
  });

  // prevent if any invalid
  form.addEventListener('submit', event => {
    let formValid = true;

    Object.keys(fields).forEach(fieldId => {
      const input = document.getElementById(fieldId);
      const { validate, message } = fields[fieldId];
      if (!validate(input.value)) {
        showError(fieldId, message);
        formValid = false;
      } else {
        showError(fieldId, '');
      }
    });

    if (!formValid) {
      event.preventDefault();
    }
  });
});