<?php
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_GET['ItemId'])) {
    die("Error: No Item Found.");
}
$Id = (int) $_GET['ItemId'];

$con = mysqli_connect("localhost", "root", "", "shopping");
$sql = "SELECT * FROM Item_Master WHERE ItemId = $Id";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $Id = $row['ItemId'];
    $Name = $row['ItemName'];
    $Description = $row['Description'];
    $Size = $row['Size'];
    $Price = $row['Price'];
    $Discount = $row['Discount'];
    $Total = $row['Total'];
    $Image = $row['Image'];
}
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add to Cart - Online Clothing Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <h2 style="margin-bottom: 20px;">Welcome <?php echo $_SESSION['Name']; ?> — Add to Cart</h2>

    <div  style=" display:inline-block; justify-content: space-between; align-items: center;">
      <form method="post" action="Insert.php?Id=<?php echo $Id; ?>">

        <p><strong >Item Name:</strong> <?php echo $Name; ?></p>
        <p><strong>Description:</strong> <?php echo $Description; ?></p>
        <p><img src="../Products/<?php echo $Image; ?>"style="border-radius: 10px; hight=125px; width=125px; "></p>
        <p><strong>Size:</strong> <?php echo $Size; ?></p>
        <p>
          <strong>Quantity:</strong>
          <input type="number" name="txtQty" value="1" min="1" required style="width: 100%; padding: 8px;">
        </p>
        <p><strong>Price:</strong> <?php echo $Price; ?> Tk</p>
        <p><strong>Discount:</strong> <?php echo $Discount; ?>%</p>
        <p><strong>Total:</strong> <?php echo $Total; ?> Tk</p>

        <input type="submit" value="Add To Cart" class="button-green" style="margin-top: 10px;">
      </form>
    </div>

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>