<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Your Cart - Online Clothing Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">
    <h2 style="margin-bottom: 20px;">Welcome <?php echo $_SESSION['Name']; ?> — Your Cart</h2>

    <section class="features" style="flex-direction: column; gap: 20px;">
      <?php
      $con = mysqli_connect("localhost", "root", "", "shopping");

      $sql = "SELECT shopping_cart.CartId, shopping_cart.ItemName, shopping_cart.Quantity, shopping_cart.Total, item_master.`Size`, item_master.Image
FROM shopping_cart, item_master
WHERE item_master.ItemName = shopping_cart.ItemName 
AND shopping_cart.CustomerId = ".$_SESSION['ID']."";



      $result = mysqli_query($con, $sql);
      $GrandTotal = 0;

      while ($row = mysqli_fetch_array($result)) {
          $Id = $row['CartId'];
          $ItemName = $row['ItemName'];
          $Size = $row['Size'];
          $Quantity = $row['Quantity'];
          $Total = $row['Total'];
          $Image = $row['Image'];
          $GrandTotal += $Total;
      ?>
      <div class="feature-card" style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h3><?php echo $ItemName; ?></h3>
          <p><strong>Size:</strong> <?php echo $Size; ?></p>
          <p><strong>Quantity:</strong> <?php echo $Quantity; ?></p>
          <p><strong>Total:</strong> <?php echo $Total; ?> Tk</p>
          <a href="DeleteCart.php?CartId=<?php echo $Id; ?>" class="btn" style="margin-top: 10px;">Remove</a>
        </div>
        <div>
          <img src="../Products/<?php echo $Image; ?>" width="120" height="120" alt="<?php echo $ItemName; ?>" style="border-radius: 10px;">
        </div>
      </div>
      <?php } ?>

      <div class="feature-card" style="text-align: right;">
        <h3>Total Price: <?php echo $GrandTotal; ?> Tk</h3>
        <a href="checkout.php" class="btn" style="margin-top: 10px;">Proceed to Checkout</a>
      </div>
    </section>
  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>