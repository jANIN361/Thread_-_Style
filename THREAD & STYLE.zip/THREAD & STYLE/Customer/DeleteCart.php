<?php
$Id = $_GET['CartId'];

$con = mysqli_connect("localhost", "root", "", "shopping");

$sql = "DELETE FROM shopping_cart WHERE CartId = '$Id'";
mysqli_query($con, $sql);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Item Deleted</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">
    <div class="feature-card" style="text-align: center;">
      <h2>Item Deleted Successfully</h2>
      <p>You have removed the item from your cart.</p>
      <a href="Cart.php" class="btn" style="margin-top: 15px;">Back to Cart</a>
    </div>
  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

<!---
<script>
  alert("Item Deleted Successfully");
  window.location = 'Cart.php';
</script>
-->
</body>
</html>