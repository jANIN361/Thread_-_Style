<div id="right-col">

  <!-- Category List -->
  <div class="feature-card" style="margin-bottom: 30px;">
    <h3 style="margin-bottom: 10px;">Categories</h3>
    <ul class="side">
      <?php
      $con = mysqli_connect("localhost", "root", "", "shopping");
      $sql = "SELECT * FROM Category_Master";
      $result = mysqli_query($con, $sql);

      while ($row = mysqli_fetch_array($result)) {
          $Id = $row['CategoryId'];
          $CategoryName = $row['CategoryName'];
          echo "<li style='margin-bottom: 6px;'><a href='Products.php?CategoryId=$Id' style='color: white;'>$CategoryName</a></li>";
      }

      mysqli_close($con);
      ?>
    </ul>
  </div>

<div style="text-align: center;">
    <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 20px;">
      <img src="img/checkout.png" class="icon-small" alt="Checkout Icon">
      <a href="checkout.php" class="button-green" style="padding: 6px 10px; font-size: 14px;">Proceed To Checkout</a>
    </div>

    <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
      <img src="img/order.png" class="icon-small" alt="Order Icon">
      <a href="History.php" class="button-green" style="padding: 6px 12px; font-size: 14px;">Order History</a>
    </div>
  </div>

</div>