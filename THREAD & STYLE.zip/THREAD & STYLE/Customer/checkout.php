<?php
session_start();

$con = mysqli_connect("localhost", "root", "", "shopping");

// Move items to final order table
$sql = "INSERT INTO Shopping_Cart_Final(CustomerID, ItemName, Quantity, Price, Total, OrderDate)
        SELECT CustomerID, ItemName, Quantity, Price, Total, OrderDate
        FROM Shopping_Cart
        WHERE CustomerID = " . $_SESSION['ID'];
mysqli_query($con, $sql);

// Clear the cart
$sql = "DELETE FROM Shopping_Cart WHERE CustomerID = " . $_SESSION['ID'];
mysqli_query($con, $sql);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Checkout Complete</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">
    <div class="feature-card" style="text-align: center;">
      <h2>Thank you for your order!</h2>
      <p>Your purchase has been successfully completed.</p>
      <a href="Products.php" class="btn" style="margin-top: 15px;">Back to Products</a>
    </div>
  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

<!--
<script>
  alert("Thank You For Your order");
  window.location = 'Cart.php';
</script>
-->

</body>
</html>