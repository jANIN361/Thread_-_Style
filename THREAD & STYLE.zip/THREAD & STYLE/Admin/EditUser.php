<?php
if (!isset($_SESSION)) {
    session_start();
}

$Id = $_GET['AdminId'] ?? '';

$con = mysqli_connect("localhost", "root", "", "shopping");
$sql = "SELECT * FROM Admin_Master WHERE AdminId = $Id";
$result = mysqli_query($con, $sql);

$Name = $Password = '';
if ($row = mysqli_fetch_array($result)) {
    $Id = $row['AdminId'];
    $Name = $row['UserName'];
    $Password = $row['Password'];
}
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit User - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">

  <div id="content" class="container">

    <h2 style="margin-bottom: 20px;">Edit User</h2>

    <div class="feature-card">
      <form method="post" action="UpdateUser.php">
        <div style="margin-bottom: 15px;">
          <label for="txtUserId">User Id:</label><br />
          <input
            type="text"
            name="txtUserId"
            id="txtUserId"
            value="<?php echo $Id; ?>"
            readonly
            style="width: 100%; padding: 8px;"
          />
        </div>

        <div style="margin-bottom: 15px;">
          <label for="txtUserName">User Name:</label><br />
          <input
            type="text"
            name="txtUserName"
            id="txtUserName"
            value="<?php echo $Name; ?>"
            required
            style="width: 100%; padding: 8px;"
          />
        </div>

        <div style="margin-bottom: 15px;">
          <label for="txtPass">Password:</label><br />
          <input
            type="password"
            name="txtPass"
            id="txtPass"
            value="<?php echo $Password; ?>"
            required
            style="width: 100%; padding: 8px;"
          />
        </div>

        <input type="submit" value="Update Record" class="btn" />
      </form>
    </div>
  </div>
  <?php include('Right.php'); ?>
</div>
<?php include('Footer.php'); ?>
</body>
</html>