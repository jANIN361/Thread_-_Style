<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Category Management - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <h2 style="margin-bottom: 20px;">Category Management</h2>

    <!-- Add Category Form -->
    <div class="feature-card" style="margin-bottom: 40px;">
      <h3 style="margin-bottom: 15px;">Create New Category</h3>
      <form action="InsertCategory.php" method="post" enctype="multipart/form-data">
        <div style="margin-bottom: 15px;">
          <label>Category Name:</label>
          <input type="text" name="txtName" required style="width: 100%; padding: 8px;">
        </div>
        <div style="margin-bottom: 15px;">
          <label>Description:</label>
          <textarea name="txtDesc" rows="3" required style="width: 100%; padding: 8px;"></textarea>
        </div>
        <div style="margin-bottom: 15px;">
          <label>Upload Image:</label>
          <input type="file" class="button-green" name="txtFile" accept="image/*" required>
        </div>
        <input type="submit" value="Submit" class="button-green">
      </form>
    </div>

    <!-- Category List Table -->
    <div class="feature-card">
      <h3 style="margin-bottom: 15px;">Category List</h3>
      <table style="width:100%; border-collapse: collapse;">
        <thead>
          <tr style="background-color: #9cd99c;">
            <th style="text-align:left; padding: 10px;">Id</th>
            <th style="text-align:left; padding: 10px;">Category Name</th>
            <th style="text-align:left; padding: 10px;">Description</th>
            <th style="text-align:left; padding: 10px;">Edit</th>
            <th style="text-align:left; padding: 10px;">Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $con = mysqli_connect("localhost", "root", "", "shopping");
          $sql = "SELECT * FROM Category_Master";
          $result = mysqli_query($con, $sql);
          $records = 0;

          while ($row = mysqli_fetch_array($result)) {
              $records++;
              $Id = $row['CategoryId'];
              $CategoryName = $row['CategoryName'];
              $Description = $row['Description'];
              echo "<tr style='border-top: 1px solid #ccc;'>
                      <td style='padding: 10px;'>$Id</td>
                      <td style='padding: 10px;'>$CategoryName</td>
                      <td style='padding: 10px;'>$Description</td>
                      <td style='padding: 10px;'><a href='EditCategory.php?CatId=$Id' class='btn'>Edit</a></td>
                      <td style='padding: 10px;'><a href='DeleteCategory.php?CatId=$Id' class='btn'>Delete</a></td>
                    </tr>";
          }

          echo "<tr><td colspan='5' style='padding-top: 15px;'>Total <strong>$records</strong> Records</td></tr>";

          mysqli_close($con);
          ?>
        </tbody>
      </table>
    </div>

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>