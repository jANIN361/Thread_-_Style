<?php
$Id = $_POST['txtId'] ?? '';
$Name = $_POST['txtName'] ?? '';
$Desc = $_POST['txtDesc'] ?? '';

if ($Id && $Name && $Desc) {
    $con = mysqli_connect("localhost", "root", "", "shopping");
    $sql = "UPDATE Category_Master SET CategoryName='$Name', Description='$Desc' WHERE CategoryId=$Id";
    mysqli_query($con, $sql);
    mysqli_close($con);

    echo "<script>alert('Category Updated Successfully'); window.location='Category.php';</script>";
} else {
    echo "<script>alert('Invalid submission'); window.location='Category.php';</script>";
}
?>