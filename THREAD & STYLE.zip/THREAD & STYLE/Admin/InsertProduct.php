<?php

session_start();

$cmbCategory = isset($_GET['CategoryId']) ? intval($_GET['CategoryId']) : 0;
$txtName = $_POST['txtName'] ?? '';
$txtDesc = $_POST['txtDesc'] ?? '';
$txtSize = $_POST['txtSize'] ?? '';
$txtPrice = $_POST['txtPrice'] ?? 0;
$txtDiscount = $_POST['txtDiscount'] ?? 0;
$txtFinal = $_POST['txtFinal'] ?? 0;

if (isset($_FILES['txtFile']) && $_FILES['txtFile']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = '../Products/';
    $filename = basename($_FILES['txtFile']['name']);
    $targetFilePath = $uploadDir . $filename;

    if (!move_uploaded_file($_FILES['txtFile']['tmp_name'], $targetFilePath)) {
        die('Error uploading file.');
    }
} else {
    die('No file uploaded or upload error.');
}

$con = mysqli_connect("localhost", "root", "", "shopping");

if (!$con) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Prepare and sanitize input for SQL query
$txtName = mysqli_real_escape_string($con, $txtName);
$txtDesc = mysqli_real_escape_string($con, $txtDesc);
$txtSize = mysqli_real_escape_string($con, $txtSize);
$filename = mysqli_real_escape_string($con, $filename);
$txtPrice = floatval($txtPrice);
$txtDiscount = floatval($txtDiscount);
$txtFinal = floatval($txtFinal);

$sql = "INSERT INTO Item_Master (CategoryId, ItemName, Description, Size, Image, Price, Discount, Total) 
        VALUES ($cmbCategory, '$txtName', '$txtDesc', '$txtSize', '$filename', $txtPrice, $txtDiscount, $txtFinal)";

if (mysqli_query($con, $sql)) {
    mysqli_close($con);
    header("Location: Products.php?CategoryId=$cmbCategory");
    exit;
} else {
    mysqli_close($con);
    die('Error inserting product: ' . mysqli_error($con));
}
?>