<?php
$Id = $_GET['OfferId'] ?? '';

if ($Id) {
    $con = mysqli_connect("localhost", "root", "", "shopping");

    $sql = "DELETE FROM Offer_Master WHERE OfferId = '$Id'";

    mysqli_query($con, $sql);
    mysqli_close($con);

    echo '<script type="text/javascript">alert("Offer Deleted Successfully"); window.location="Offers.php";</script>';
} else {
    echo '<script type="text/javascript">alert("Invalid Request"); window.location="Offers.php";</script>';
}