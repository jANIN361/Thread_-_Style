<?php
$Id = $_GET['FeedbackId'] ?? '';

if ($Id) {
    $con = mysqli_connect("localhost", "root", "", "shopping");

    $sql = "DELETE FROM Feedback_Master WHERE FeedbackId = '$Id'";

    mysqli_query($con, $sql);
    mysqli_close($con);

    echo '<script type="text/javascript">alert("Feedback Deleted Successfully"); window.location="Feedback.php";</script>';
} else {
    echo '<script type="text/javascript">alert("Invalid Request"); window.location="Feedback.php";</script>';
}
?>