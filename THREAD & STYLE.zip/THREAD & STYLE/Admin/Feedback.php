<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Customer Feedback - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>
  <?php include('Header.php'); ?>
  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Feedback From Customers</h2>

      <div class="feature-card">
        <h3 style="margin-bottom: 15px;">Customer Feedback</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background-color: #9cd99c;">
              <th style="padding: 10px; text-align: left;">Id</th>
              <th style="padding: 10px; text-align: left;">Customer Name</th>
              <th style="padding: 10px; text-align: left;">Feedback</th>
              <th style="padding: 10px; text-align: left;">Date</th>
              <th style="padding: 10px; text-align: left;">Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $con = mysqli_connect("localhost", "root", "", "shopping");

            $sql = "SELECT Feedback_Master.FeedbackId, Customer_Registration.CustomerName, Feedback_Master.Feedback, Feedback_Master.Date
                    FROM Feedback_Master
                    JOIN Customer_Registration ON Feedback_Master.CustomerId = Customer_Registration.CustomerId";

            $result = mysqli_query($con, $sql);

            $records = mysqli_num_rows($result);

            while ($row = mysqli_fetch_array($result)) {
              $Id = $row['FeedbackId'];
              $Name = $row['CustomerName'];
              $Feedback = $row['Feedback'];
              $Date = $row['Date'];
            ?>
              <tr style="border-top: 1px solid #ccc;">
                <td style="padding: 10px;"><?php echo $Id; ?></td>
                <td style="padding: 10px;"><?php echo $Name; ?></td>
                <td style="padding: 10px;"><?php echo $Feedback; ?></td>
                <td style="padding: 10px;"><?php echo $Date; ?></td>
                <td style="padding: 10px;">
                  <a href="DeleteFeedback.php?FeedbackId=<?php echo $Id; ?>" class="btn">Delete</a>
                </td>
              </tr>
            <?php
            }
            ?>
            <tr>
              <td colspan="5" style="padding: 10px;">
                Total <strong><?php echo $records; ?></strong> Records
              </td>
            </tr>
            <?php mysqli_close($con); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php include('Right.php'); ?>
    <div style="clear: both;"></div>
  </div>
  <?php include('Footer.php'); ?>
</body>

</html>