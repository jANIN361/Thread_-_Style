<?php
session_start();

require_once('../Connections/shop.php');

// Get CustomerId safely from GET params, default -1 if missing
$CustomerId = isset($_GET['CustomerId']) ? intval($_GET['CustomerId']) : -1;

$query = "SELECT CustomerName, Address, City, Email, Mobile, Gender FROM customer_registration WHERE CustomerId = $CustomerId";

$result = mysqli_query($shop, $query);

if (!$result || mysqli_num_rows($result) === 0) {
  // No customer found or error
  $customer = null;
} else {
  $customer = mysqli_fetch_assoc($result);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Shipping Address Detail - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>

  <?php include('Header.php'); ?>

  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Welcome Administrator</h2>

      <p><b>Shipping Address Details</b></p> <br>

      <?php if ($customer): ?>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr>
            <td style="background-color:rgb(29, 99, 29); padding: 10px; font-weight: bold;">Customer Name</td>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px;"><?php echo  ($customer['CustomerName']); ?></td>
          </tr>
          <tr>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px; font-weight: bold;">Address</td>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px;"><?php echo  ($customer['Address']); ?></td>
          </tr>
          <tr>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px; font-weight: bold;">City</td>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px;"><?php echo  ($customer['City']); ?></td>
          </tr>
          <tr>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px; font-weight: bold;">Email</td>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px;"><?php echo  ($customer['Email']); ?></td>
          </tr>
          <tr>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px; font-weight: bold;">Mobile</td>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px;"><?php echo  ($customer['Mobile']); ?></td>
          </tr>
          <tr>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px; font-weight: bold;">Gender</td>
            <td style="background-color:  rgb(29, 99, 29); padding: 10px;"><?php echo  ($customer['Gender']); ?></td>
          </tr>
        </table>
      <?php else: ?>
        <p>No customer details found.</p>
      <?php endif; ?>

    </div>

    <?php include('Right.php'); ?>
    <div style="clear: both;"></div>
  </div>
  <?php include('Footer.php'); ?>
</body>

</html>
<?php
if ($result) {
  mysqli_free_result($result);
}
?>