<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Orders Management - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>
  <?php include('Header.php'); ?>
  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Welcome Administrator</h2>

      <div class="feature-card">
        <h3 style="margin-bottom: 15px;">Orders List</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background-color: #9cd99c">
              <th style="padding: 10px; text-align: left;">ID</th>
              <th style="padding: 10px; text-align: left;">Customer Name</th>
              <th style="padding: 10px; text-align: left;">Item Name</th>
              <th style="padding: 10px; text-align: left;">Quantity</th>
              <th style="padding: 10px; text-align: left;">Price</th>
              <th style="padding: 10px; text-align: left;">Total</th>
              <th style="padding: 10px; text-align: left;">Shipping Address</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $con = mysqli_connect("localhost", "root", "", "shopping");

            $sql = "SELECT customer_registration.CustomerId, customer_registration.CustomerName, shopping_cart_final.ItemName, shopping_cart_final.Quantity, shopping_cart_final.Price, shopping_cart_final.Total 
                    FROM customer_registration 
                    JOIN shopping_cart_final ON customer_registration.CustomerId = shopping_cart_final.CustomerId";

            $result = mysqli_query($con, $sql);

            $records = mysqli_num_rows($result);

            while ($row = mysqli_fetch_array($result)) {
              $Id = $row['CustomerId'];
              $CustomerName = $row['CustomerName'];
              $ItemName = $row['ItemName'];
              $Quantity = $row['Quantity'];
              $Price = $row['Price'];
              $Total = $row['Total'];
            ?>
              <tr style="border-top: 1px solid #ccc;">
                <td style="padding: 10px;"><?php echo $Id; ?></td>
                <td style="padding: 10px;"><?php echo $CustomerName; ?></td>
                <td style="padding: 10px;"><?php echo $ItemName; ?></td>
                <td style="padding: 10px;"><?php echo $Quantity; ?></td>
                <td style="padding: 10px;"><?php echo $Price; ?></td>
                <td style="padding: 10px;"><?php echo $Total; ?></td>
                <td style="padding: 10px;">
                  <a href="Detail.php?CustomerId=<?php echo $Id; ?>" class="btn">Shipping Address</a>
                </td>
              </tr>
            <?php
            }
            ?>
            <tr>
              <td colspan="7" style="padding: 10px;">
                Total <strong><?php echo $records; ?></strong> Records
              </td>
            </tr>
            <?php mysqli_close($con); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php include('Right.php'); ?>
    <div style="clear: both;"></div>
  </div>
  <?php include('Footer.php'); ?>
</body>

</html>