<?php
$UserName = $_POST['txtUserName'] ?? '';
$Password = $_POST['txtPassword'] ?? '';

if ($UserName && $Password) {
    $con = mysqli_connect("localhost", "root", "", "shopping");

    $sql = "INSERT INTO Admin_Master (UserName, Password) VALUES ('$UserName', '$Password')";

    mysqli_query($con, $sql);
    mysqli_close($con);

    echo '<script type="text/javascript">alert("User Inserted Successfully"); window.location="User.php";</script>';
} else {
    echo '<script type="text/javascript">alert("Invalid Input. Please fill all fields."); window.location="User.php";</script>';
}
?>