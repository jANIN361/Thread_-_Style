<?php
if (!isset($_SESSION)) {
    session_start();
}

$Id = $_GET['CatId'] ?? '';

$con = mysqli_connect("localhost", "root", "", "shopping");
$sql = "SELECT * FROM Category_Master WHERE CategoryId = $Id";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $Id = $row['CategoryId'];
    $Name = $row['CategoryName'];
    $Description = $row['Description'];
}
mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Category - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <h2 style="margin-bottom: 20px;">Edit Category</h2>

    <div class="feature-card">
      <form method="post" action="UpdateCategory.php">
        <div style="margin-bottom: 15px;">
          <label>Category Id:</label>
          <input type="text" name="txtId" value="<?php echo $Id; ?>" readonly style="width: 100%; padding: 8px;">
        </div>

        <div style="margin-bottom: 15px;">
          <label>Category Name:</label>
          <input type="text" name="txtName" value="<?php echo $Name; ?>" required style="width: 100%; padding: 8px;">
        </div>

        <div style="margin-bottom: 15px;">
          <label>Description:</label>
          <textarea name="txtDesc" rows="4" required style="width: 100%; padding: 8px;"><?php echo $Description; ?></textarea>
        </div>

        <input type="submit" value="Update Record" class="button-green">
      </form>
    </div>

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>