<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - Online Clothing Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <!-- Hero Section -->
    <section class="hero">
      <div class="hero-text">
        <h1>Welcome Administrator</h1>
        <p>Manage your categories, users, and feedback efficiently using the admin tools.</p>
        <a href="Products.php" class="btn">Go to Manage Products</a>
      </div>
      <div class="hero-img">
        <img src="img/admin.png" alt="Admin Hero">
      </div>
    </section>

    <!-- Featured Categories
    <section class="features">
      <div class="feature-card">
        <img src="img/Jeans.jpg" alt="Jeans">
        <h3>Jeans</h3>
      </div>
      <div class="feature-card">
        <img src="img/asd.jpg" alt="Blazers">
        <h3>Blazers</h3>
      </div>
      <div class="feature-card">
        <img src="img/images.jpg" alt="T-Shirts">
        <h3>T-Shirts</h3>
      </div>
    </section> -->

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>