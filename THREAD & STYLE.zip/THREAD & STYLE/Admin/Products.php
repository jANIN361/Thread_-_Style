

<?php
session_start();
require_once('../Connections/shop.php');

$queryCategories = "SELECT CategoryId, CategoryName FROM category_master";
$resultCategories = mysqli_query($shop, $queryCategories);

$categoryId = isset($_GET['CategoryId']) ? intval($_GET['CategoryId']) : -1;

$queryItems = "SELECT ItemId, ItemName, Size, Image, Price, Discount, Total FROM item_master WHERE CategoryId = $categoryId";
$resultItems = mysqli_query($shop, $queryItems);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Products - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>
  <?php include('Header.php'); ?>
  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Manage Products</h2>

      <!-- Category selection -->
      <div class="feature-card" style="margin-bottom: 30px;">
        <form method="get" action="Products.php">
          <label for="categorySelect">Select Category:</label>
          <select name="CategoryId" id="categorySelect" onchange="this.form.submit()" required style="padding:8px; width: 100%; max-width: 300px;">
            <option value="">-- Select Category --</option>
            <?php while ($cat = mysqli_fetch_assoc($resultCategories)) : ?>
              <option value="<?php echo $cat['CategoryId']; ?>" <?php if ($cat['CategoryId'] == $categoryId) echo 'selected'; ?>>
                <?php echo ($cat['CategoryName']); ?>
              </option>
            <?php endwhile; ?>
          </select>
        </form>
      </div>

      <?php if ($categoryId != -1) : ?>
        <!-- Add Product Form -->
        <div class="feature-card" style="margin-bottom: 40px;">
          <h3 style="margin-bottom: 15px;">Add New Product</h3>
          <form action="InsertProduct.php?CategoryId=<?php echo $categoryId; ?>" method="post" enctype="multipart/form-data">
            <div style="margin-bottom: 15px;">
              <label for="txtName">Item Name:</label><br />
              <input type="text" name="txtName" id="txtName" required style="width: 100%; padding: 8px;" />
            </div>
            <div style="margin-bottom: 15px;">
              <label for="txtDesc">Description:</label><br />
              <textarea name="txtDesc" id="txtDesc" rows="3" required style="width: 100%; padding: 8px;"></textarea>
            </div>
            <div style="margin-bottom: 15px;">
              <label for="txtFile">Upload Image:</label><br />
              <input type="file" class="button-green" name="txtFile" id="txtFile" accept="image/*" required />
            </div>
            <div style="margin-bottom: 15px;">
              <label for="txtSize">Size:</label><br />
              <input type="text" name="txtSize" id="txtSize" required style="width: 100%; padding: 8px;" />
            </div>
            <div style="margin-bottom: 15px;">
              <label for="txtPrice">Price:</label><br />
              <input type="number" step="0.01" name="txtPrice" id="txtPrice" required style="width: 100%; padding: 8px;" />
            </div>
            <div style="margin-bottom: 15px;">
              <label for="txtDiscount">Discount:</label><br />
              <input type="number" step="0.01" name="txtDiscount" id="txtDiscount" required style="width: 100%; padding: 8px;" />
            </div>
            <div style="margin-bottom: 15px;">
              <label for="txtFinal">Final Price:</label><br />
              <input type="number" step="0.01" name="txtFinal" id="txtFinal" required style="width: 100%; padding: 8px;" />
            </div>
            <input type="submit" value="Submit" class="button-green" />
          </form>
        </div>
<!-- Product List -->
        <div class="feature-card">
          <h3 style="margin-bottom: 15px;">Product List</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <thead style="background-color: #9cd99c;">
              <tr>
                <th style="padding: 10px;">ItemId</th>
                <th style="padding: 10px;">ItemName</th>
                <th style="padding: 10px;">Size</th>
                <th style="padding: 10px;">Image</th>
                <th style="padding: 10px;">Price</th>
                <th style="padding: 10px;">Discount</th>
                <th style="padding: 10px;">Total</th>
                <th style="padding: 10px; text-align: left;">Delete</th>
              </tr>
            </thead>
            <tbody>
              <?php if (mysqli_num_rows($resultItems) > 0) : ?>
                <?php while ($item = mysqli_fetch_assoc($resultItems)) : ?>
                  <tr>
                    <td style="padding: 10px;"><?php echo $item['ItemId']; ?></td>
                    <td style="padding: 10px;"><?php echo ($item['ItemName']); ?></td>
                    <td style="padding: 10px;"><?php echo ($item['Size']); ?></td>
                    <td style="padding: 10px;">
                      <img src="../Products/<?php echo ($item['Image']); ?>" alt="<?php echo ($item['ItemName']); ?>" height="125" width="125" />
                    </td>
                    <td style="padding: 10px;"><?php echo number_format($item['Price'], 2); ?></td>
                    <td style="padding: 10px;"><?php echo number_format($item['Discount'], 2); ?></td>
                    <td style="padding: 10px;"><?php echo number_format($item['Total'], 2); ?></td>
                    <td style="padding: 10px;">
                      <form method="POST" action="Delete_Products.php" onsubmit="return confirm('Are you sure you want to delete this item?');">
                        <input type="hidden" name="ItemId" value="<?= (int)$item['ItemId'] ?>">
                        <input type="hidden" name="CategoryId" value="<?= $categoryId ?>">
                        <button type="submit" class="button-green">Delete</button>
                      </form>
                    </td>

                  </tr>
                <?php endwhile; ?>
              <?php else : ?>
                <tr>
                  <td colspan="7" style="padding: 10px; text-align: center;">No products found for this category.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      <?php else : ?>
        <p>Please select a category to view or add products.</p>
      <?php endif; ?>

    </div>
    <?php include('Right.php'); ?>
  </div>
  <?php include('Footer.php'); ?>
</body>

</html>

<?php
mysqli_free_result($resultCategories);
mysqli_free_result($resultItems);
?>