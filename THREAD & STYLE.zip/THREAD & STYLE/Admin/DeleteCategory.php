<?php
$Id = $_GET['CatId'] ?? '';

if ($Id) {
    $con = mysqli_connect("localhost", "root", "", "shopping");
    $sql = "DELETE FROM Category_Master WHERE CategoryId = '$Id'";
    mysqli_query($con, $sql);
    mysqli_close($con);

    echo "<script>alert('Category Deleted Successfully'); window.location='Category.php';</script>";
} else {
    echo "<script>alert('Invalid Request'); window.location='Category.php';</script>";
}
?>